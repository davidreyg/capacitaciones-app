<?php

// This is the default Laravel Model Factory File.
// You do not need to use it. Instead, use your Containers factories.
